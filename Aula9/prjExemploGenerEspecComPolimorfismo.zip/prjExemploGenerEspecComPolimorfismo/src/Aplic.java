import fatec.poo.model.FuncionarioHorista;
import java.util.HashSet;

/**
 *
 * @author Nicolas
 */
public class Aplic {

    public static void main(String[] args) {
        FuncionarioHorista funcHor = new FuncionarioHorista(1010, "Nicolas", "07/10/25", 15);
        
        funcHor.setQtdHorTrab(244);
        
        System.out.println("Salario Bruto: " + funcHor.calcSalBruto());
        System.out.println("Desconto: " + funcHor.calcDesconto());
        System.out.println("Salario liquido: " + funcHor.calcSalLiquido());
        System.out.println();
        
        
    }
    
}
