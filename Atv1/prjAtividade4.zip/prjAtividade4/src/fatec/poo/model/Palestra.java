package fatec.poo.model;
import java.util.ArrayList;

/**
 *
 * @author Nicolas
 */
public class Palestra {
    private String data;
    private String tema;
    private double valor;
    private Palestrante palestrante;
    private ArrayList<Participante> participantes;
    private int numPart;
    
    public Palestra(String tema, double valor){
        this.tema = tema;
        this.valor = valor;
        participantes = new ArrayList<>();
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    public void setPalestrante(Palestrante palestrante){
        this.palestrante = palestrante;
        palestrante.addPalestra(this);
    }
    
    public Palestrante getPalestrante(){
        return(palestrante);
    }
    
    public String getData(){
        return(data);
    }
    
    public String getTema(){
        return(tema);
    }
    
    public double getValor(){
        return(valor);
    }
    
    public double calcTotalFaturado(){
        double total = 0;
        
        for(int i = 0;i < participantes.size();i++){
            switch(participantes.get(i).getTipo()){
                case 'c':{
                 total += valor;
                 break;
                }
                case 'e':{
                    total += valor * 0.85;
                    break;
                }
                case 'i':{
                    total += valor * 0.8;
                    break;
                }
            }
            
        }
        
        return(total);
    }
    
    public void addParticipante(Participante participante){
        participantes.add(participante);
        
    }
}
