package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Palestra {
    private String data;
    private String tema;
    private double valor;
    private Palestrante palestrante;
    private Participante[] participantes;
    private int numPart;
    
    public Palestra(String tema, double valor){
        this.tema = tema;
        this.valor = valor;
        participantes = new Participante[5];
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    public void setPalestrante(Palestrante palestrante){
        this.palestrante = palestrante;
    }
    
    public Palestrante getPalestrante(){
        return(palestrante);
    }
    
    public String getData(){
        return(data);
    }
    
    public String getTema(){
        return(tema);
    }
    
    public double getValor(){
        return(valor);
    }
    
    public double calcTotalFaturado(){
        double total = 0;
        
        for(int i = 0;i <= numPart;i++){
            if(participantes[i].getTipo() == 'c')
                total += valor;
            else if(participantes[i].getTipo() == 'e')
                total += valor * 0.15;
            else if(participantes[i].getTipo() == 'i')
                total += valor * 0.2;
        }
        
        return(total);
    }
    
    public void addParticipante(Participante participante){
        participantes[numPart] = participante;
        numPart++;
    }
}
