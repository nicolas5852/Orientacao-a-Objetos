package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Palestrante extends Pessoa {
    private String empresa;
    private double taxaCobranca;
    private Palestra palestras[];
    private int numPal;
    
    public Palestrante(String nome, String cpf, String empresa){
        super(nome, cpf);
        this.empresa = empresa;
        palestras = new Palestra[2];
    }
    
    public String getEmpresa(){
        return(empresa);
    }
    
    public double getTaxaCobranca(){
        return(taxaCobranca);
    }
    
    public void setTaxaCrobanca(double taxaCobranca){
        this.taxaCobranca = taxaCobranca;
    }
    
    public double calcTotalReceberPalestras(){
        double total = 0;
        
        for(int i = 0;i <= numPal;i++){
            total += palestras[i].calcTotalFaturado();
        }
        
        return(total * (taxaCobranca/100));
    }
    
    public void addPalestra(Palestra palestra){
        palestras[numPal] = palestra;
        numPal++;
    } 
}
