package fatec.poo.model;
import java.util.ArrayList;

/**
 *
 * @author Nicolas
 */
public class Palestrante extends Pessoa {
    private String empresa;
    private double taxaCobranca;
    private ArrayList<Palestra> palestras;
    private int numPal;
    
    public Palestrante(String nome, String cpf, String empresa){
        super(nome, cpf);
        this.empresa = empresa;
        palestras = new ArrayList<>();
    }
    
    public String getEmpresa(){
        return(empresa);
    }
    
    public double getTaxaCobranca(){
        return(taxaCobranca);
    }
    
    public void setTaxaCrobanca(double taxaCobranca){
        this.taxaCobranca = taxaCobranca;
    }
    
    public double calcTotalReceberPalestras(){
        double total = 0;
        
        for(int i = 0;i < palestras.size();i++){
            total += palestras.get(i).calcTotalFaturado();
        }
        
        return(total * (taxaCobranca/100));
    }
    
    public void addPalestra(Palestra palestra){
        palestras.add(palestra);
    } 
}
