package fatec.poo.model;

/**
 *
 * @author 0030482423014
 */
public class Participante extends Pessoa {
    private char tipo;
    private Palestra palestra;
    
    public Participante(String nome, String cpf, char tipo){
        super(nome, cpf);
        this.tipo = tipo;
    }
    
    public char getTipo(){
        return(tipo);
    }
    
    public void setPalestra(Palestra palestra){
        this.palestra = palestra;
    }
}
