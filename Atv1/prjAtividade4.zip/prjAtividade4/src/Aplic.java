import fatec.poo.model.Palestra;
import fatec.poo.model.Palestrante;
import fatec.poo.model.Participante;
import java.text.DecimalFormat;


/**
 *
 * @author Nicolas
 */
public class Aplic {
    public static void main(String[] args) {
        Palestra pal1 = new Palestra("Financias", 100);
        Palestra pal2 = new Palestra("Educacao", 250);
        
        Palestrante palestrante1 = new Palestrante("Richard", "11111111111", "Palestras");
        palestrante1.setTaxaCrobanca(50);
        
        
        Participante part1 = new Participante("Nicolas", "2222222222", 'e');
        Participante part2 = new Participante("Lucas", "3333333333", 'e');
        Participante part3 = new Participante("Beatriz", "4444444444", 'c');
        Participante part4 = new Participante("Matheus", "5555555555", 'c');
        Participante part5 = new Participante("Helen", "6666666666", 'i');
        
        part1.setPalestra(pal1);
        part2.setPalestra(pal1);
        part3.setPalestra(pal1);
        part4.setPalestra(pal2);
        part5.setPalestra(pal2);
        
        pal1.setPalestrante(palestrante1);
        pal1.setPalestrante(palestrante1);
        
        DecimalFormat formatDinheiro = new DecimalFormat("#,##0.00");
        
        System.out.println("CPF Palestrante: " + palestrante1.getCpf());
        System.out.println("Nome: " + palestrante1.getNome());
        System.out.println("Taxa de cobrança: " + formatDinheiro.format(palestrante1.getTaxaCobranca()) + "%");
        System.out.println("Valor total a receber pelas palestras: " + formatDinheiro.format(palestrante1.calcTotalReceberPalestras()));
        
        
       
        
    }
    
}
