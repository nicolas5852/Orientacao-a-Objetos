/**
 *
 * @author Nicolas
 */
public class Aplic {
    public static void main(String[] args) {
        
    }
    
}
