package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Professor extends Pessoa {
    private int regProfessor;
    private double salario;
    
    public Professor(int r, String n, String nd){
        super(n, nd);
        regProfessor = r;  
    }
    
    public void setSalario(double s){
        salario = s;
    }
    
    public int getRegProfessor(){
        return regProfessor;
    }
    
    public double getSalario(){
        return salario;
    }
}
