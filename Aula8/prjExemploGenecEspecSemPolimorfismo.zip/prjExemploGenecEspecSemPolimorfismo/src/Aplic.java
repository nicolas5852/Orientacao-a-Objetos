import fatec.poo.model.Aluno;
import fatec.poo.model.Professor;

/**
 *
 * @author Nicolas
 */
public class Aplic {
    public static void main(String[] args) {
        Aluno objAlu = new Aluno(1010, "Nicolas", "08/03/2004");
        
        objAlu.setMensalidade(1500.00);
        
        System.out.println("Registro Escolar: " + objAlu.getRegEscolar());
        System.out.println("Nome: " + objAlu.getNome());
        System.out.println("Data de nascimento: " + objAlu.getDataNasc());
        System.out.println("Mensalidade: " + objAlu.getMensalidade());
        
        Professor objProf = new Professor(2021, "Matheus", "07/02/2000");
        
        objProf.setSalario(2700.00);
        
        System.out.println("\nRegistro Professor: " + objProf.getRegProfessor());
        System.out.println("Nome: " + objProf.getNome());
        System.out.println("Data de nascimento: " + objProf.getDataNasc());
        System.out.println("Salario: " + objProf.getSalario());
    }
    
}
