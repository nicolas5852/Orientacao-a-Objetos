package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Projeto {
    private int codigo;
    private String descricao;
    private String dtInicio;
    private String dtTermino;
    private Funcionario[] funcionarios;
    private int numFunc;
    
    public Projeto(int c, String d){
        codigo = c;
        descricao = d;
        numFunc = 0;
        funcionarios = new Funcionario[5];
    }
    
    public void setDtInicio(String x){
        dtInicio = x;
    }
    
    public void setDtTermino(String x){
        dtTermino = x;
    }
    
    public int getCodigo(){
        return(codigo);
    }
    
    public String getDescricao(){
        return(descricao);
    }
    
    public String getDtInicio(){
        return(dtInicio);
    }
    
    public String getDtTermino(){
        return(dtTermino);
    }
    
    public void listarFuncionarios(){
        System.out.println("\n\nCodigo:" + this.getCodigo());
        System.out.println("Descriçao:" + this.getDescricao());
        System.out.println("Data inicio:" + this.getDtInicio());
        System.out.println("Data Termino:" + this.getDtTermino());
        System.out.println("\nRegistro\tNome\t\tCargo\t\tDepartamento");
        
        for(int i = 0;i < numFunc;i++)
        {
            System.out.println(funcionarios[i].getRegistro() + "\t\t" + funcionarios[i].getNome() + 
                    "\t\t" + funcionarios[i].getCargo() + "\t\t" + funcionarios[i].getDepartamento().getNome());
        }
    }
    
    public void addFuncionario(Funcionario f){
        funcionarios[numFunc] = f;
        numFunc++;
    }
    
}
