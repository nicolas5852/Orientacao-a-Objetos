package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Departamento {
    private String sigla;
    private String nome;
    
    public Departamento(String s, String n){
        this.sigla = s;
        this.nome = n;
    }
    
    public String getSigla(){
        return sigla;
    }
    
    public String getNome(){
        return nome;
    }
}
