package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Departamento {
    private String sigla;
    private String nome;
    private Funcionario[] funcionarios;
    
    private int numFunc;
    
    public Departamento(String s, String n){
        this.sigla = s;
        this.nome = n;
        funcionarios = new Funcionario[5];
        numFunc = 0;
    }
    
    public String getSigla(){
        return sigla;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void addFuncionario(Funcionario f){
        funcionarios[numFunc] = f;
        numFunc++;
    }
    
    public void listarFuncionarios(){
        System.out.println("\nSigla: " + sigla);
        System.out.println("Nome: " + nome);
        System.out.println("Qtde. de funcionarios: " + numFunc);
        System.out.println("\nRegistro\tNome\t\tCargo");
        
        for(int i = 0;i < numFunc;i++)
        {
            System.out.println(funcionarios[i].getRegistro() + "\t\t" + funcionarios[i].getNome() + 
                    "\t\t" + funcionarios[i].getCargo());
        }
    }
}
