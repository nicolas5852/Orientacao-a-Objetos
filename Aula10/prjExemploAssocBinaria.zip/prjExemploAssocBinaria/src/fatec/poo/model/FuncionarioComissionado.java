package fatec.poo.model;



/**
 *
 * @author romerac
 */
public class FuncionarioComissionado extends Funcionario{
    private double salBase;
    private double taxaComissao;
    private double totalVendas;
    
    public FuncionarioComissionado(int r, String n, String dta, double txc){
        super(r, n, dta);
        taxaComissao = txc;
    }
    
    public void setSalBase(double sb){
        salBase = sb;
    }
    
    public double getSalBase(){
        return(salBase);
    }
    
    public double getTotalVendas(){
        return(totalVendas);
    }
    
    public double getTaxaComissao(){
        return(taxaComissao);
    }
    
    public void addVendas(double vendas){
        totalVendas += vendas;
    }
    
    public double calcSalBruto(){
        return(salBase + (taxaComissao/100 * totalVendas));
    }
    
    
    public double calcGratificacao(){
        if(totalVendas <= 5000){
            return(0);
        }
        else if (totalVendas > 5000 && totalVendas <= 10000){
            return(0.03*calcSalBruto());
        }
        else{
            return(0.05*calcSalBruto());
        }
        
        /*
        if(totalVendas <= 5000){
            return(0);
        }
        else {
            if (totalVendas <= 10000){
                return(0.03*calcSalBruto());
            }
            else{
                return(0.05*calcSalBruto());
            }
        }
        */
    }
    
    //aplicando o polimofrismo
    //sobreposião (override) do método
    public double calcSalLiquido(){
        return(super.calcSalLiquido() + calcGratificacao());
    }
    
}