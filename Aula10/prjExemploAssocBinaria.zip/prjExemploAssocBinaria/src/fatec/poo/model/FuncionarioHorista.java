package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class FuncionarioHorista extends Funcionario {
    private double valHorTrab;
    private int qtdHorTrab;
    
    public FuncionarioHorista(int r, String n, String dta, double vht){
        super(r, n, dta);        
        valHorTrab = vht;
    }
    
    public double calcSalBruto(){
        return(valHorTrab * qtdHorTrab);
    }
    
    public void setQtdHorTrab(int h){
        qtdHorTrab = h;
    }
}
