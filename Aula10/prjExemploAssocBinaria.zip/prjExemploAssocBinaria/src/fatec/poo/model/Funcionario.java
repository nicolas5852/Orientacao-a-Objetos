package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public abstract class Funcionario {
    private int registro;
    private String nome;
    private String dtAdmissao;
    private String cargo;
    private Departamento departamento;
    private Projeto projeto;
    
    public Funcionario(int r, String n, String dta){
        registro = r;
        nome = n;
        dtAdmissao = dta;
    }
    
    abstract public double calcSalBruto();      
    
    public double calcDesconto(){
        return(0.10 * calcSalBruto());
    }
    
    public double calcSalLiquido(){
        return(calcSalBruto() - calcDesconto());
    }
    
    public Departamento getDepartamento(){
        return departamento;
    }
    
    public String getNome(){
        return nome;
    }
    
    public int getRegistro(){
        return registro;
    }
    
    public void setCargo(String c){
        cargo = c;
    }
    
    public String getCargo(){
        return cargo;
    }
    
    public void setProjeto(Projeto p){
        projeto = p;
        p.addFuncionario(this);
    }
    
    public void setDepartamento(Departamento d){
        departamento = d;
        d.addFuncionario(this);
    }
}
