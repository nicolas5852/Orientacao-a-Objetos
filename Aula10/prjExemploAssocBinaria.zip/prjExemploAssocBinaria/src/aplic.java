
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.Departamento;

/**
 *
 * @author Nicolas
 */
public class aplic {
    public static void main(String[] args) {
         FuncionarioHorista funcHor = new FuncionarioHorista(1010, "Nicolas", "07/10/25", 15);
         
         Departamento dep1 = new Departamento("cp", "Compras");
         Departamento dep2 = new Departamento("rh", "Recursos humanos");
         
    }
    
}
