
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioMensalista;
import fatec.poo.model.Departamento;
import java.util.HashSet;

/**
 *
 * @author Nicolas
 */
public class aplic {
    public static void main(String[] args) {
         FuncionarioHorista funcHor = new FuncionarioHorista(1010, "Nicolas", "07/10/25", 15);
         FuncionarioMensalista funcMen = new FuncionarioMensalista(2020, "Joao", "01/05/2025", 1600);
         FuncionarioComissionado funcCom = new FuncionarioComissionado(3030, "Lucas", "10/09/2020", 5000);
                 
         Departamento dep1 = new Departamento("cp", "Compras");
         Departamento dep2 = new Departamento("rh", "Recursos humanos");
         
         //Efetivando a ligação entre um objeto da clase funcionario horista com departamento
         funcHor.setDepartamento(dep1);
         
         System.out.println("O funcionario horista " + funcHor.getNome() + " Trabalha no departamento " 
                 + funcHor.getDepartamento().getNome());
         
         funcMen.setDepartamento(dep1);
         
         System.out.println("O funcionario horista " + funcMen.getNome() + " Trabalha no departamento " 
                 + funcMen.getDepartamento().getNome());
         
         funcCom.setDepartamento(dep2);
         
         System.out.println("O funcionario horista " + funcCom.getNome() + " Trabalha no departamento " 
                 + funcCom.getDepartamento().getNome());
        
    }
    
}
