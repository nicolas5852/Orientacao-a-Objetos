/**
 *
 * @author Nicolas
 */
public class Aplic {
    public static void main(String[] args) {
        Retangulo objRet = new Retangulo();
        
        objRet.setAltura(5.0);
        objRet.setBase(8.0);
        
        System.out.println("Altura do objeto: " + objRet.getAltura());
        System.out.println("Base do objeto: " + objRet.getBase());
        System.out.println("Perimetro do objeto: " + objRet.calcPerimetro());
        System.out.println("Area do objeto: " + objRet.calcArea());
        System.out.println("Diagonal do objeto: " + objRet.calcDiagonal());
        System.out.println();
        
        Retangulo objRet1 = new Retangulo();
        
        objRet1.setAltura(3.0);
        objRet1.setBase(4.0);
        
        System.out.println("Altura do objeto 1: " + objRet1.getAltura());
        System.out.println("Base do objeto 1: " + objRet1.getBase());
        System.out.println("Perimetro do objeto 1: " + objRet1.calcPerimetro());
        System.out.println("Area do objeto 1: " + objRet1.calcArea());
        System.out.println("Diagonal do objeto 1: " + objRet1.calcDiagonal());
        System.out.println();
        
    }
    
}
