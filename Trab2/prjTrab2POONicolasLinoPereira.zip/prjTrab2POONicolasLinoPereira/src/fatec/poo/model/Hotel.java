
package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Hotel {
    int codigo;
    String nome;
    String endereco;
    String telefone;
    double valorDiaria;
    double totalFaturamento;
    
    public Hotel(int codigo, String nome){
        this.codigo = codigo;
        this.nome = nome;
        totalFaturamento = 0;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setValorDiaria(double valorDiaria) {
        this.valorDiaria = valorDiaria;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public double getTotalFaturamento() {
        return totalFaturamento;
    }
    
    public void addValorHospedagem(double valor){
        totalFaturamento += valor;
    }
}
