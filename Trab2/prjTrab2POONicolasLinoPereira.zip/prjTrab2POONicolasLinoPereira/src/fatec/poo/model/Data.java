package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Data {
    int dia;
    int mes;
    int ano;
    
    public Data(int dia, int mes, int ano){
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAno() {
        return ano;
    }
    
    public String obterData(){
        return(dia + "/" + mes + "/" + ano);
    }
    
    public int calcDiasCorridos(){
        int diaAno;
        int[] diasMeses = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int mesesAnteriores = 0;
        
        for(int i = 1; i < mes;i++){
            mesesAnteriores += diasMeses[i];
        }
        
        if(mes>2 && ano % 4 == 0){
            mesesAnteriores += 1;
        }
        
        return((int)(((ano-1)-1900)*365.25)+mesesAnteriores+dia);
        
    }
    
    public int subtrairDatas(Data subtrair){
        return(calcDiasCorridos() - subtrair.calcDiasCorridos());
    }
}
