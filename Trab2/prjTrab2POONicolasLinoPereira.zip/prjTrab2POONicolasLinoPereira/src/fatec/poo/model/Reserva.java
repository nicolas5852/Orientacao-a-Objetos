package fatec.poo.model;

/**
 *
 * @author Nicolas
 */
public class Reserva {
    int codigo;
    String nomeHosp;
    Data dataEntrada;
    Data dataSaida;
    Double valorHosped;
    Hotel hotelHosped;
    
    public Reserva(int codigo, String nomeHosp, Data dataEntrada, Hotel hotelHosped){
        this.codigo = codigo;
        this.nomeHosp = nomeHosp;
        this.dataEntrada = dataEntrada;
        this.hotelHosped = hotelHosped;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNomeHosp() {
        return nomeHosp;
    }

    public Data getDataEntrada() {
        return dataEntrada;
    }

    public Data getDataSaida() {
        return dataSaida;
    }

    public Double getValorHosped() {
        return valorHosped;
    }

    public Hotel getHotelHosped() {
        return hotelHosped;
    }  
    
    public int encerrarReserva(Data dataSaida, Hotel hotel){
        this.dataSaida = dataSaida;
        int diasHosp = dataSaida.subtrairDatas(dataEntrada);
        this.valorHosped = diasHosp * hotel.getValorDiaria();
        
        return(diasHosp);
    }
}
