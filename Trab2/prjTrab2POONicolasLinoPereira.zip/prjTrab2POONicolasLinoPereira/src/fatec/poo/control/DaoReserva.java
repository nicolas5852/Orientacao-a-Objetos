package fatec.poo.control;
import fatec.poo.model.Reserva;
import fatec.poo.model.Data;
import fatec.poo.model.Hotel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author Nicolas
 */
public class DaoReserva {
    private Connection conn;
    
    public DaoReserva(Connection conn){
        this.conn = conn;
    }
    
    public Reserva consultar (int codigoReserva, Hotel hotelHosped) {
        Reserva objReserva = null;         
       
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("SELECT * from tblReserva where Codigo_Res = ?");
            
            ps.setInt(1, codigoReserva);
            ResultSet rs = ps.executeQuery();
           
            if (rs.next()) {
                Data entrada;
                int diaEntrada = Integer.parseInt(rs.getString("DataEntrada_Res").substring(0, 1));
                int mesEntrada = Integer.parseInt(rs.getString("DataEntrada_Res").substring(3, 4));
                int anoEntrada = Integer.parseInt(rs.getString("DataEntrada_Res").substring(6, 9));
                
                entrada = new Data(diaEntrada, mesEntrada, anoEntrada);
                
                try{
                    Data saida;
                    int diaSaida = Integer.parseInt(rs.getString("DataSaida_Res").substring(0, 1));
                    int mesSaida = Integer.parseInt(rs.getString("DataSaida_Res").substring(3, 4));
                    int anoSaida = Integer.parseInt(rs.getString("DataSaida_Res").substring(6, 9));
                
                    saida = new Data(diaSaida, mesSaida, anoSaida);
                
                    objReserva = new Reserva(rs.getInt("Codigo_Res"), rs.getString("NomeHosp_Res"), entrada, hotelHosped);
                    objReserva.encerrarReserva(saida, hotelHosped);
                }catch(SQLException ex){
                    System.out.println(ex.toString());
                }
            }
        }
        catch (SQLException ex) { 
             System.out.println(ex.toString());   
        }
        return(objReserva);
    }    
     
    public void checkIn(Reserva objReserva) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("INSERT INTO tblReserva(Codigo_Res, NomeHosp_Res, DataEntrada_Res , Codigo_Hot)"
                    + " VALUES(?,?,?,?)");
            ps.setInt(1, objReserva.getCodigo());
            ps.setString(2, objReserva.getNomeHosp());
            ps.setString(3, objReserva.getDataEntrada().obterData());
            ps.setInt(4, objReserva.getHotelHosped().getCodigo());
                      
            ps.execute(); //envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }  
    
        public void checkOut(Reserva objReserva) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("UPDATE tblReserva set "
                    + "DataSaida_Res = ?,"
                    + "ValorHosped_Res = ?"
                    + " VALUES(?,?)");
            ps.setString(1, objReserva.getDataSaida().obterData());
            ps.setDouble(2, objReserva.getValorHosped());
                      
            ps.execute(); //envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }
    }
    
}
