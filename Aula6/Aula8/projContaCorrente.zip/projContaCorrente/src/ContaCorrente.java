/**
 *
 * @author Nicolas
 */
public class ContaCorrente {
    private int numero;
    private double saldo;
    
    public ContaCorrente(int _numero, double _saldo){
        numero = _numero;
        saldo = _saldo;
    }
           
    
    public int getNumero(){
        return numero;
    }
    public double getSaldo(){
        return saldo;
    }
    
    public void sacar(double saque){
        if(saldo >= saque)
            saldo -= saque;
        else
            System.out.println("\n\tSaldo insuficiente!");
    }
    
    public void depositar(double depos){
        saldo += depos;
    }
}
