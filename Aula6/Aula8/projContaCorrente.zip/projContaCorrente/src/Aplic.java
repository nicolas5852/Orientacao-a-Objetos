import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class Aplic {
    public static void main(String[] args) {
        int numero;
        double saldo = 0;
        int opt = 0;
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Digite o numero da conta: ");
        numero = entrada.nextInt();
        
        do{            
            System.out.print("Digite o saldo inicial da conta: ");
            saldo = entrada.nextDouble();
            
            if(saldo < 0)
                System.out.print("\n\tNao e permitido saldo negativo!");
        }while(saldo < 0);    
        
        ContaCorrente conta = new ContaCorrente(numero, saldo);
        
        while(opt != 4){
            System.out.println("\n\n\tEscolha uma acao:");
            System.out.println("\t1-Depositar");
            System.out.println("\t2-Sacar");
            System.out.println("\t3-Consultar saldo");
            System.out.println("\t4-Sair\n");
            
            opt = entrada.nextInt();
            
            switch(opt){
                
                case 1:{
                    double depos = 0;                    
                    do{            
                        System.out.print("\nDigite o valor do deposito: ");
                        depos = entrada.nextDouble();
                        
                        if(depos < 0)
                        System.out.print("\n\tEscolha um valor acima de 0!");
                    }while(depos <= 0);    
                    
                    conta.depositar(depos);
                    
                    break;
                }
                case 2:{
                    double saque;
                    System.out.print("\nDigite o valor do saque: ");
                    saque = entrada.nextDouble();
                    
                    conta.sacar(saque);
                    break;
                }
                case 3:{
                    
                    System.out.print("\n\tSaldo atual: " + conta.getSaldo());                    
                    break;
                }
                case 4:{
                    System.out.print("\n\tFim!");
                    break;
                }
                
                default:{
                    System.out.println("\n\tOpcao inexistente!");
                    break;
                }
            }
        }
    }
    
}
