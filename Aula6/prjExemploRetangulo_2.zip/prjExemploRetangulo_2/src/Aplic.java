import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double medAlt, medBase;
        int opcao = 0;
        
        System.out.print("Digite a medida da altura: ");
        medAlt = entrada.nextDouble();     
        System.out.print("\n\nDigite a medida da base: ");
        medBase = entrada.nextDouble();
        
        Retangulo objRet = new Retangulo();        
        objRet.setAltura(medAlt);
        objRet.setBase(medBase);
        
        do{
            System.out.println("\n\n1-Consultar area");
            System.out.println("2-Consultar Perimetro");
            System.out.println("3-Consultar Diagonal");
            System.out.println("4-Sair");
            System.out.println("\t\tDigite sua escolha: ");
            opcao = entrada.nextInt();
            
            switch(opcao)
            {
                case 1:
                {
                    System.out.println("Area do retangulo: " + objRet.calcArea());
                    break;
                }
                case 2:
                {
                    System.out.println("Perimetro do retangulo: " + objRet.calcPerimetro());
                    break;
                }
                case 3:
                {
                    System.out.println("Diagonal do retangulo: " + objRet.calcDiagonal());
                    break;
                }
                case 4:
                {
                    System.out.println("Fim!");
                    break;
                }
                default:
                {
                    System.out.println("Nenhuma opcao selecionada!");
                    break;
                }
            }            
        }while(opcao!=4);
    }
    
}
